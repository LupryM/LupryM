﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjectAttemp3
{
    internal class arrayclass
    {
        public static string[] Match;
        public static double[] LowestPrice;
        
    }
}
